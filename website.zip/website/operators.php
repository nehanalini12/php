<?php
    // Arithmetic + , -, *, /, %
    $a = 10;
    $b = 5;
    $sum = $a + $b;
    $product = $a * $b;
    echo "Sum: {$sum} <br>";
    echo "Product: {$product} <br>";

    // Comparison:  ==, !=, >, <, >=, <= || => true / false
    // syntax: ?: => condition? truth value: false value
    $isEqual = ($a == $b);
    $isGreater = $a > $b;


    echo "Is a equal to b?".($isEqual ? "YES": "NO"). "<br>";
    echo "Is a greater to b?".($isGreater ? "YES": "NO"). "<br>";

    // Logical Operators - && || !
    $x = true;
    $y = false;
    $result = $x && $x; // true
    $result2 = $x && $y; // false

    $result3 = $x || $y; // true || false -> true

    echo "Result of X AND X:" . ($result? "TRUE":"FALSE"). "<br>";
    echo "Result of X AND Y:" . ($result2? "TRUE":"FALSE"). "<br>";
    echo "Result of X OR Y:" . ($result3? "TRUE":"FALSE"). "<br> <br> <br>";

    // Increment & decrement;
    $count = 5;
    echo "Count before increment:".$count ."<br>";
    $count++;
    echo "Count after increment:".$count ."<br>";
    $count--;
    echo "Count after decrement:".$count ."<br>";

    // Operator Precedence:
    // 1. () 
    // 2. **
    // 3. *, /, 
    // 4. +, -
    
    // echo 1+2-3*4/5**6;
    // echo 1+2-3*4/15625;
    // echo 1+2-12/15625;
    // echo 1+2-0.000768;
    // echo 3-0.000768;s
    // echo 2.999232;


?>