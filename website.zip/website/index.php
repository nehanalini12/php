<?php
    // Variables
    
    //* reusable container that holds a data and we can give a name to it (variable name)

    //? $variable_name = value;

    // String:
    $firstname = "John Doe <br>";

    echo $firstname;

    // String, Integer, Float, Boolean, Array, Object, null

    $name = "Mounika";
    $food = "Cake";
    
    echo "Hello {$name} <br>"; //1st way {}

    echo "Hi " .$name."<br>"; //2nd way .

    // Integer:
    $age = 21;
    $users = 2;
    $quantity = 2;
    $cakePrice = 250;

    echo "you are {$age} years old <br>";
    echo "There are {$users} users online right.<br>";
    echo "You would like to buy {$quantity} items of books?<br>";

    // Float:
    $gpa=2.8;
    $price=3.89;
    
    echo "You gpa is {$gpa} <br>";
    echo "Your coffee price is \${$price} <br>";
    echo "your cake price is $".$price ."<br>";


    // boolean : true / false;
    $employeed = true;
    $online = false;
    $forSale = true;

    echo "Online status : {$online} <br>";


    // Cakes 2 = 250;=> total
    $total = null;
    echo "Your have ordered {$quantity} X {$food}s <br>";
    $total = $quantity * $cakePrice;
    echo "Your total is {$total} <br>";

    // [1,23,456,7687]; arr[1] => 23

    // Array:
    // 1. Indexed array 
    $fruits = ["apple", "banana", "cherry"];

    array_push($fruits, "Grapes");

    print_r($fruits);

    $remainaingval = array_pop($fruits);
    echo $remainaingval;
    print_r($fruits);
    $noOfFruits = count($fruits);

    echo $fruits[1] . "<br>";
    echo "You have {$noOfFruits} no of fruits!!! <br>";

    // 2. Associative Array
    $person = [
        "name" => "John",
        "age" => 30,
        "city" => "Hyderabad"
    ];

    echo $person["city"] . "<br>";

    // 3. Multidimentional Array

    $people = [
        ["name" => "Alice", "age" => 25],
        ["name" => "Bob", "age" => 22],
        ["name" => "Charlie", "age" => 28],
    ];

    echo $people[1]["name"];


?>
