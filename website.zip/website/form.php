<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="form.php" method="post">
        <label>username:</label> <br>
        <input type="text" name="username" /> <br> <br>
        <label>password:</label> <br>
        <input type="password" name="password" /> <br> <br>
        <input type="submit" value="Login"/>
    </form>
</body>
</html>

<!-- POST 
GET
PUT 
DELETE -->


<?php
    // echo "This is username:::". $_GET["username"]. "<br>";
    // echo "this is passsword:::". $_GET["password"];

    echo "This is username:::". $_POST["username"]. "<br>";
    echo "this is passsword:::". $_POST["password"];
?>