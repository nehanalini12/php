<?php
    // reusable block of code 

    // syntax
    // function functionName($parameter){
    //     return $result;
    // }

    function sayHello($name="Guest"){ //parameter
        echo "Hello ".$name. "<br>";
    }

    sayHello(); //arguments
    sayHello("Bob"); //arguments

    function add($a, $b){
        return $a+$b;
    }

    $result = add(2,3);
    echo $result;

    // Anonymous functions
    $greet = function($name){
        return "<br>Hello ".$name. "<br>";
    };

    echo $greet("Neha");

    // Scope in functions

    // 1. local scope, 2. global scope, 3. static variable

    $globalVar = 10;

    function testFunc(){
        global $globalVar;
        $localVar = 5;
        echo "Global: $globalVar , Local:  $localVar <br>";
    }

    testFunc();

    function countCall(){
        static $count = 0;
        $count++;
        echo "Function called $count times. <br>";
    }

    countCall();
    countCall();
    countCall();
?>