<!-- if, else, elseif switch -->
<!-- for, while, do-while, foreach -->


<?php
    $age = 20;

    if($age < 18){
        echo "You are minor";
    } elseif ($age < 65){
        echo "You are an adult <br> <br>";
    } else {
        echo "You are senior";
    }

    $day = "Sunday";
    switch($day){
        case "Monday":
            echo "Start of the week <br> <br>";
            break;
        case "Friday":
            echo "alomst weekend <br> <br>";
            break;
        case "Saturday":
        case "Sunday":
            echo "It's weekend as well <br> <br>";
            break;
        default:
            echo "It's a regular day <br> <br>";
    }


    // for loop
    for($i = 1; $i <=5; $i++){
        echo "Number: $i <br>";
    }
    // while
    $count = 1;
    while($count <=3){
        echo "Count: $count <br>";
        $count++;
    }

    // do while
    $count1 = 1;
    do{
        echo "Count: $count1 <br>";
        $count1++;
    } while($count1 <= 3);

    // for each

    $colors = ["red", "green", "blue"];
    foreach($colors as $color){
        echo "color is: $color <br>";
    }
?>